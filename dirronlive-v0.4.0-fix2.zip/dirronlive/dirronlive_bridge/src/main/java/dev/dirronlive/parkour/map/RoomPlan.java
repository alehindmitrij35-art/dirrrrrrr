package dev.dirronlive.parkour.map;

import java.util.List;

/**
 * Готовая комната: маршрут, точки для действий и чертёж блоков.
 * Все координаты абсолютные.
 */
public final class RoomPlan {
    public final int number;
    public final Theme theme;
    /** Платформы по порядку: 0 — старт, последняя — финиш. */
    public final List<Platform> platforms;
    /** Точка появления (центр стартовой платформы) и взгляд на первый прыжок. */
    public final double spawnX, spawnY, spawnZ;
    public final float spawnYaw;
    /** Ниже этой высоты игрок считается упавшим. */
    public final int fallY;
    /** Границы комнаты (включая декор). */
    public final int minX, minY, minZ, maxX, maxY, maxZ;
    /** Блоки «Моста зрителя» через заранее отмеченный разрыв. */
    public final List<int[]> bridge;
    /** Блоки «Секретной срезки» до более поздней точки комнаты. */
    public final List<int[]> shortcut;
    /** Платформы, которые могут стать «Исчезающей ступенью» (не старт и не финиш). */
    public final List<Integer> vanishCandidates;
    /** Глаза логотипа в комнате 100 (иначе пусто). */
    public final List<int[]> eyes;
    public final Blueprint blueprint;

    RoomPlan(int number, Theme theme, List<Platform> platforms, double spawnX, double spawnY,
             double spawnZ, float spawnYaw, int fallY, int[] bounds, List<int[]> bridge,
             List<int[]> shortcut, List<Integer> vanishCandidates, List<int[]> eyes,
             Blueprint blueprint) {
        this.number = number;
        this.theme = theme;
        this.platforms = List.copyOf(platforms);
        this.spawnX = spawnX;
        this.spawnY = spawnY;
        this.spawnZ = spawnZ;
        this.spawnYaw = spawnYaw;
        this.fallY = fallY;
        this.minX = bounds[0];
        this.minY = bounds[1];
        this.minZ = bounds[2];
        this.maxX = bounds[3];
        this.maxY = bounds[4];
        this.maxZ = bounds[5];
        this.bridge = List.copyOf(bridge);
        this.shortcut = List.copyOf(shortcut);
        this.vanishCandidates = List.copyOf(vanishCandidates);
        this.eyes = List.copyOf(eyes);
        this.blueprint = blueprint;
    }

    public Platform start() {
        return platforms.get(0);
    }

    public Platform finish() {
        return platforms.get(platforms.size() - 1);
    }

    public boolean contains(double x, double y, double z) {
        return x >= minX && x < maxX + 1 && z >= minZ && z < maxZ + 1 && y >= fallY - 64 && y < maxY + 32;
    }

    /** Игрок стоит на финишной платформе (ноги на её верхней грани). */
    public boolean isOnFinish(double x, double y, double z) {
        Platform f = finish();
        return f.contains(x, z) && y >= f.y() + 0.9 && y <= f.y() + 2.5;
    }

    /** Индекс ближайшей к игроку платформы (по горизонтали и высоте). */
    public int nearestPlatform(double x, double y, double z) {
        int best = 0;
        double bestDistance = Double.MAX_VALUE;
        for (Platform p : platforms) {
            double dx = p.centerX() - x;
            double dz = p.centerZ() - z;
            double dy = (p.y() + 1) - y;
            double d = dx * dx + dz * dz + dy * dy * 2;
            if (d < bestDistance) {
                bestDistance = d;
                best = p.index();
            }
        }
        return best;
    }
}
