import 'dart:io';

/// Имя папки программы внутри каталога данных пользователя.
const appDataFolderName = 'Dirronlive';

/// Каталог данных приложения для текущего пользователя Windows:
/// `%APPDATA%\Dirronlive` (обычно `C:\Users\<имя>\AppData\Roaming\Dirronlive`).
///
/// [environment] передаётся только в тестах.
Directory resolveDataDirectory({Map<String, String>? environment}) {
  final env = environment ?? Platform.environment;

  String? pick(String key) {
    final value = env[key];
    if (value == null || value.trim().isEmpty) return null;
    return value;
  }

  final profile = pick('USERPROFILE');
  final base = pick('APPDATA') ??
      pick('LOCALAPPDATA') ??
      (profile != null ? '$profile\\AppData\\Roaming' : null) ??
      pick('HOME') ??
      Directory.systemTemp.path;

  return Directory('$base${Platform.pathSeparator}$appDataFolderName');
}
