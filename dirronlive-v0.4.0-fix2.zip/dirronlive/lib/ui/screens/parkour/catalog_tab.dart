import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/format.dart';
import '../../../features/parkour/gift_catalog.dart';
import '../../../features/settings/settings_controller.dart';
import '../../theme/app_colors.dart';
import '../../theme/app_theme.dart';
import '../../widgets/common.dart';
import 'rules_tab.dart';

/// «Каталог подарков»: сверка подарков эфира с тем, что видно в редакторе.
class CatalogTab extends ConsumerStatefulWidget {
  const CatalogTab({super.key});

  @override
  ConsumerState<CatalogTab> createState() => _CatalogTabState();
}

class _CatalogTabState extends ConsumerState<CatalogTab> {
  final _search = TextEditingController();

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(giftCatalogProvider);
    final catalog = state.catalog;
    final nickname = ref.watch(settingsProvider).tiktokNickname;
    final query = _search.text;
    final shown = catalog.gifts.where((g) => g.matchesQuery(query)).toList();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Panel(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                catalog.fetchedAt == null
                    ? 'Каталог ещё не загружен'
                    : 'Сохранённый каталог: ${catalog.gifts.length} подарков · '
                        '${formatDateTime(catalog.fetchedAt!)}'
                        '${catalog.streamer == null ? '' : ' · эфир @${catalog.streamer}'}',
                key: const Key('catalog-summary'),
                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: AppColors.text),
              ),
              const SizedBox(height: 6),
              Text(
                nickname.isEmpty
                    ? 'Сначала укажите ник TikTok в Настройках → Подключения.'
                    : 'Каталог берётся у TikTok для эфира @$nickname через коннектор Dirronlive. '
                        'Лучше обновлять во время эфира: у разных эфиров и регионов подарки отличаются.',
                style: const TextStyle(fontSize: 13, height: 1.4, color: AppColors.textMuted),
              ),
              const SizedBox(height: 14),
              FilledButton.icon(
                key: const Key('catalog-refresh'),
                onPressed: state.busy
                    ? null
                    : () => ref.read(giftCatalogProvider.notifier).refreshAndCheck(),
                icon: state.busy
                    ? const SizedBox(
                        width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                    : const Icon(Icons.sync_rounded, size: 18),
                label: Text(state.busy ? 'Проверяю каталог…' : 'Обновить и проверить каталог'),
              ),
              if (state.report != null) ...[
                const SizedBox(height: 16),
                _ReportView(report: state.report!, catalog: catalog),
              ],
            ],
          ),
        ),
        const SizedBox(height: 16),
        Panel(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              TextField(
                key: const Key('catalog-search'),
                controller: _search,
                onChanged: (_) => setState(() {}),
                style: const TextStyle(fontSize: 15, color: AppColors.text),
                decoration: appInputDecoration(
                  label: 'Поиск по названию или ID',
                  hint: 'Роза, Rose или 5655',
                  icon: Icons.search_rounded,
                ),
              ),
              const SizedBox(height: 12),
              if (catalog.gifts.isEmpty)
                const Text(
                  'Подарков пока нет. Нажмите «Обновить и проверить каталог». До этого в правилах '
                  'можно выбрать популярные подарки по названию.',
                  style: TextStyle(fontSize: 13, color: AppColors.textFaint),
                )
              else if (shown.isEmpty)
                const Text('Ничего не найдено', style: TextStyle(fontSize: 13, color: AppColors.textFaint))
              else
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    for (final g in shown.take(120))
                      Container(
                        key: Key('catalog-gift-${g.id}'),
                        width: 220,
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: AppColors.surfaceAlt,
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: AppColors.border),
                        ),
                        child: Row(
                          children: [
                            GiftAvatar(imageUrl: g.imageUrl, size: 30),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(g.displayName,
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: const TextStyle(
                                          fontSize: 13, fontWeight: FontWeight.w700, color: AppColors.text)),
                                  Text(
                                    'ID ${g.id}${g.diamonds > 0 ? ' · ${g.diamonds} алм.' : ''}'
                                    '${g.imageUrl == null ? ' · без значка' : ''}',
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(fontSize: 11, color: AppColors.textFaint),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                  ],
                ),
              if (shown.length > 120)
                Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: Text('Показаны первые 120 из ${shown.length} — уточните поиск.',
                      style: const TextStyle(fontSize: 12, color: AppColors.textFaint)),
                ),
            ],
          ),
        ),
      ],
    );
  }
}

class _ReportView extends StatelessWidget {
  const _ReportView({required this.report, required this.catalog});

  final CatalogReport report;
  final GiftCatalog catalog;

  @override
  Widget build(BuildContext context) {
    final ok = report.allAvailable;
    final lines = <String>[
      'Проверено: ${formatDateTime(report.checkedAt)}',
      if (report.fetched)
        'Коннектор: ${report.connectorCount} · сохранено: ${report.savedCount} · '
            'в редакторе: ${report.editorCount}'
      else if (catalog.fetchedAt != null)
        'Показан сохранённый каталог от ${formatDateTime(catalog.fetchedAt!)} '
            '(${catalog.gifts.length} подарков) — он может быть устаревшим.'
      else
        'Сохранённого каталога нет.',
      if (report.missingInSaved.isNotEmpty) 'Не сохранились: ${report.missingInSaved.join(', ')}',
      if (report.missingInEditor.isNotEmpty) 'Нет в редакторе: ${report.missingInEditor.join(', ')}',
      if (report.added.isNotEmpty) 'Новые с прошлой проверки: ${report.added.take(20).join(', ')}'
          '${report.added.length > 20 ? ' и ещё ${report.added.length - 20}' : ''}',
      if (report.removed.isNotEmpty) 'Пропали из каталога: ${report.removed.take(20).join(', ')}'
          '${report.removed.length > 20 ? ' и ещё ${report.removed.length - 20}' : ''}',
      if (report.rulesWithoutGift.isNotEmpty)
        'Правила с подарками не из этого эфира: ${report.rulesWithoutGift.join('; ')}',
    ];
    final title = ok
        ? 'Все подарки из каталога этого эфира доступны'
        : report.error != null
            ? (report.fetched ? 'Каталог получен с проблемой' : 'Каталог не обновлён')
            : 'Наборы подарков не совпали';
    final color = ok ? AppColors.success : (report.error != null ? AppColors.danger : AppColors.warning);
    return Container(
      key: const Key('catalog-report'),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: color.withAlpha(22),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withAlpha(120)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(ok ? Icons.check_circle_rounded : Icons.warning_amber_rounded, color: color, size: 20),
              const SizedBox(width: 8),
              Flexible(
                child: Text(title,
                    key: const Key('catalog-report-title'),
                    style: TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: color)),
              ),
            ],
          ),
          if (report.error != null) ...[
            const SizedBox(height: 6),
            Text(
              '${_kindLabel(report.errorKind)}${report.error}',
              key: const Key('catalog-report-error'),
              style: const TextStyle(fontSize: 13, color: AppColors.text),
            ),
          ],
          const SizedBox(height: 6),
          for (final line in lines)
            Padding(
              padding: const EdgeInsets.only(top: 2),
              child: Text(line, style: const TextStyle(fontSize: 13, height: 1.35, color: AppColors.textMuted)),
            ),
        ],
      ),
    );
  }

  static String _kindLabel(String? kind) => switch (kind) {
        'network' => 'Ошибка сети: ',
        'offline' => 'Эфир не найден: ',
        'service' => 'Ошибка сервиса: ',
        'storage' => 'Ошибка сохранения: ',
        _ => '',
      };
}
