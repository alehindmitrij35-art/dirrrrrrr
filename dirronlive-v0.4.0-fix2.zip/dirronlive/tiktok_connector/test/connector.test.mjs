import { test } from 'node:test';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { classifyError, normalizeCatalog, normalizeGift, parseArgs, toJsonLine } from '../lib.mjs';

const here = path.dirname(fileURLToPath(import.meta.url));
const connector = path.join(here, '..', 'connector.mjs');
const fakeLib = new URL('./fake-lib.mjs', import.meta.url).href;

function run(args, scenario, { closeStdinAfter } = {}) {
  return new Promise((resolve) => {
    const child = spawn(process.execPath, [connector, ...args], {
      env: { ...process.env, DIRRONLIVE_TIKTOK_LIB: fakeLib, DIRRONLIVE_FAKE_SCENARIO: scenario },
    });
    let out = '';
    child.stdout.on('data', (d) => { out += d; });
    if (closeStdinAfter) setTimeout(() => child.stdin.end(), closeStdinAfter);
    child.on('exit', (code) => resolve({
      code,
      lines: out.trim().split('\n').filter(Boolean).map((l) => JSON.parse(l)),
    }));
  });
}

test('normalizeGift: поля, BigInt и запасные варианты', () => {
  const g = normalizeGift({
    common: { msgId: 123456789012345678n }, giftId: 5655, groupId: 99n, repeatCount: 3,
    repeatEnd: 1, giftDetails: { giftName: 'Rose', giftType: 1 },
    user: { userId: 1n, uniqueId: 'u', nickname: 'Ник' },
  });
  assert.equal(g.msgId, '123456789012345678');
  assert.equal(g.groupId, '99');
  assert.equal(g.giftName, 'Rose');
  assert.equal(g.streakable, true);
  assert.equal(g.repeatEnd, true);
  assert.equal(g.repeatCount, 3);
  assert.equal(g.nickname, 'Ник');
  assert.equal(normalizeGift({ groupId: 0n }).groupId, null);
  assert.equal(normalizeGift({}).repeatCount, 1);
});

test('classifyError: эфир не найден, сеть, сервис', () => {
  class UserOfflineError extends Error { constructor() { super("isn't online"); this.name = 'UserOfflineError'; } }
  assert.equal(classifyError(new UserOfflineError()).status, 'offline');
  const net = new Error('connect ECONNREFUSED'); net.code = 'ECONNREFUSED';
  assert.equal(classifyError(net).kind, 'network');
  const rl = new Error('Too many'); rl.name = 'SignatureRateLimitError';
  assert.match(classifyError(rl).message, /Euler Stream/);
  assert.equal(classifyError(new Error('boom')).kind, 'service');
});

test('parseArgs и BigInt в JSON', () => {
  assert.deepEqual(parseArgs(['--user', ' @dirron ', '--key', 'k']), { user: 'dirron', key: 'k', selfCheck: false, fetchGifts: false });
  assert.equal(toJsonLine({ a: 1n }), '{"a":"1"}');
});

test('процесс: подключение, серия, одиночный подарок, конец эфира', async () => {
  const { code, lines } = await run(['--user', '@dirron'], 'gifts');
  assert.equal(code, 0);
  assert.deepEqual(lines[0], { type: 'status', status: 'connecting', uniqueId: 'dirron' });
  const connected = lines.find((l) => l.status === 'connected');
  assert.equal(connected.roomId, '7300000000000000001');
  const gifts = lines.filter((l) => l.type === 'gift');
  assert.equal(gifts.length, 7);
  assert.deepEqual(gifts.slice(0, 6).map((g) => g.repeatCount), [1, 2, 3, 4, 5, 5]);
  assert.equal(gifts[5].repeatEnd, true);
  assert.equal(gifts[5].groupId, '777');
  assert.equal(gifts[6].streakable, false);
  assert.equal(gifts[6].nickname, 'Alex');
  assert.equal(lines.at(-1).status, 'ended');
});

test('процесс: эфир не найден', async () => {
  const { lines } = await run(['--user', 'dirron'], 'offline');
  assert.equal(lines.at(-1).status, 'offline');
});

test('процесс: ошибка сети', async () => {
  const { code, lines } = await run(['--user', 'dirron'], 'network');
  assert.equal(code, 1);
  assert.equal(lines.at(-1).kind, 'network');
});

test('процесс: обрыв связи', async () => {
  const { lines } = await run(['--user', 'dirron'], 'drop');
  assert.equal(lines.at(-1).status, 'disconnected');
});

test('процесс: выходит, когда Dirronlive закрыл stdin', async () => {
  const { code, lines } = await run(['--user', 'dirron'], 'idle', { closeStdinAfter: 200 });
  assert.equal(code, 0);
  assert.equal(lines.at(-1).status, 'connected');
});

test('процесс: самопроверка библиотеки', async () => {
  const { code, lines } = await run(['--self-check'], 'gifts');
  assert.equal(code, 0);
  assert.equal(lines[0].ok, true);
});

test('normalizeCatalog: ID строкой, без повторов и пустых', () => {
  const list = normalizeCatalog([
    { id: 5655n, name: 'Rose', diamond_count: 1, image: { url_list: ['https://x/rose.png'] } },
    { id: 5655, name: 'Rose' },
    { id: 0, name: 'Zero' },
    { id: 1, name: '  ' },
    { giftId: 7934, giftName: 'Heart Me', diamondCount: 1, icon: { urlList: ['https://x/h.png'] } },
  ]);
  assert.deepEqual(list, [
    { id: '5655', name: 'Rose', diamonds: 1, image: 'https://x/rose.png' },
    { id: '7934', name: 'Heart Me', diamonds: 1, image: 'https://x/h.png' },
  ]);
  assert.deepEqual(normalizeCatalog(null), []);
  assert.equal(parseArgs(['--fetch-gifts', '--user', '@a']).fetchGifts, true);
});

test('процесс: каталог подарков эфира', async () => {
  const { code, lines } = await run(['--fetch-gifts', '--user', '@dirron'], 'gifts');
  assert.equal(code, 0);
  assert.equal(lines.length, 1);
  assert.equal(lines[0].type, 'gifts');
  assert.deepEqual(lines[0].gifts.map((g) => g.id), ['5655', '5487']);
  assert.equal(lines[0].gifts[0].image, 'https://example.test/rose.png');
});

test('процесс: каталог, когда эфира нет', async () => {
  const { code, lines } = await run(['--fetch-gifts', '--user', 'dirron'], 'offline');
  assert.equal(code, 1);
  assert.equal(lines.at(-1).status, 'offline');
});
