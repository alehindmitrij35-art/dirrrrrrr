import 'dart:async';

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/events/delivery_status.dart';
import '../../core/events/gift_event.dart';
import '../../core/providers.dart';
import '../events/event_log.dart';
import 'minecraft_link.dart';

final giftDeliveryProvider = Provider<GiftDeliveryService>((ref) {
  final service = GiftDeliveryService(ref);
  ref.onDispose(service.dispose);
  return service;
});

/// Доставка подарков в игру.
///
/// Слушает ту же шину событий, что и журнал. Журнал подписывается раньше
/// (см. `createAppContainer`), поэтому запись уже есть, когда сюда приходит
/// подарок, и статус доставки меняется прямо в ней:
///
/// * мир не готов или связь выключена → «Только в журнале»;
/// * мир готов → «Отправляется», затем по подтверждению мода
///   «Доставлено в игру»;
/// * нет подтверждения за 5 секунд → «Доставка не подтверждена»;
///   позднее подтверждение всё равно засчитывается.
///
/// Серия (комбо): пока зритель жмёт подарок, запись в журнале растёт, а в
/// игру серия уходит один раз — когда закончилась (`comboActive: false`),
/// сразу с итоговым количеством: «Alex отправил «Роза» ×5».
///
/// Подарки «Только в журнале» при входе в мир не отправляются.
class GiftDeliveryService {
  GiftDeliveryService(this._ref) {
    _giftSubscription =
        _ref.read(eventBusProvider).on<GiftEvent>().listen(_onGift);
    _ackSubscription = _ref
        .read(minecraftLinkProvider.notifier)
        .acknowledgements
        .listen(_onAck);
  }

  final Ref<Object?> _ref;
  final Map<String, _Progress> _progress = {};
  final Map<String, _Delivery> _deliveries = {};
  late final StreamSubscription<GiftEvent> _giftSubscription;
  late final StreamSubscription<String> _ackSubscription;

  EventLogController get _log => _ref.read(eventLogProvider.notifier);

  void _onGift(GiftEvent step) {
    final record = _ref.read(eventLogProvider).recordFor(step);
    if (record == null) return;
    // Серия ещё идёт — ждём её конца, чтобы отправить в игру один раз.
    if (record.isCombo && step.comboActive) return;
    final progress = _progress.putIfAbsent(record.id, _Progress.new);

    // Сколько новых подарков принёс этот шаг (для одиночного — все).
    final units = step.count - progress.handled;
    if (units <= 0) return; // повтор или запоздавший шаг комбо
    progress.handled = step.count;

    final deliveryId =
        record.isCombo ? '${record.id}:${step.count}' : record.id;
    final link = _ref.read(minecraftLinkProvider.notifier);
    final sent = _ref.read(minecraftLinkProvider).worldReady &&
        link.sendGift(
          deliveryId: deliveryId,
          record: record,
          units: units,
          comboTotal: record.isCombo ? step.count : null,
        );

    if (!sent) {
      progress.skipped += units;
      _publish(record.id, progress);
      return;
    }

    progress.pending += units;
    final timeout = _ref.read(minecraftLinkConfigProvider).ackTimeout;
    final delivery = _Delivery(record.id, units);
    _deliveries[deliveryId] = delivery;
    delivery.timer = Timer(timeout, () {
      if (!delivery.waiting) return;
      delivery.waiting = false;
      progress.pending -= units;
      progress.timedOut += units;
      _publish(record.id, progress);
    });
    _publish(record.id, progress);
  }

  void _onAck(String deliveryId) {
    final delivery = _deliveries.remove(deliveryId);
    if (delivery == null) return; // повторное подтверждение
    final progress = _progress[delivery.recordId];
    if (progress == null) return;
    delivery.timer?.cancel();
    if (delivery.waiting) {
      progress.pending -= delivery.units;
    } else {
      progress.timedOut -= delivery.units; // позднее подтверждение
    }
    delivery.waiting = false;
    progress.delivered += delivery.units;
    _publish(delivery.recordId, progress);
  }

  void _publish(String recordId, _Progress progress) {
    _log.setDelivery(recordId, progress.status,
        deliveredCount: progress.delivered);
  }

  void dispose() {
    unawaited(_giftSubscription.cancel());
    unawaited(_ackSubscription.cancel());
    for (final delivery in _deliveries.values) {
      delivery.timer?.cancel();
    }
    _deliveries.clear();
    _progress.clear();
  }
}

/// Счётчики одной записи журнала (одиночного подарка или серии комбо).
class _Progress {
  int handled = 0; // сколько подарков серии уже обработано
  int pending = 0; // отправлено, ждём подтверждения
  int delivered = 0; // показано в игре и подтверждено
  int timedOut = 0; // не подтверждено вовремя
  int skipped = 0; // мир был закрыт — только в журнале

  DeliveryStatus get status {
    if (pending > 0) return DeliveryStatus.sending;
    if (timedOut > 0) return DeliveryStatus.unconfirmed;
    if (delivered > 0 && skipped == 0) return DeliveryStatus.delivered;
    if (delivered > 0) return DeliveryStatus.partial;
    return DeliveryStatus.logOnly;
  }
}

class _Delivery {
  _Delivery(this.recordId, this.units);

  final String recordId;
  final int units;
  Timer? timer;
  bool waiting = true;
}
