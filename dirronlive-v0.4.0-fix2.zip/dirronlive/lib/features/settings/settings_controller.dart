import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/providers.dart';
import '../../core/storage/storage_exception.dart';
import 'app_settings.dart';
import 'settings_repository.dart';

final settingsRepositoryProvider = Provider<SettingsRepository>(
  (ref) => SettingsRepository(ref.watch(jsonStoreProvider)),
);

/// Сохранённые настройки. Состояние меняется только после успешной записи,
/// поэтому на экранах всегда то, что действительно лежит на диске.
final settingsProvider =
    NotifierProvider<SettingsController, AppSettings>(SettingsController.new);

class SettingsController extends Notifier<AppSettings> {
  @override
  AppSettings build() => ref.read(initialDataProvider).settings;

  /// Нормализует и сохраняет ник. Возвращает текст ошибки или `null`.
  Future<String?> saveNickname(String raw) =>
      _save(state.copyWith(tiktokNickname: normalizeTiktokNickname(raw)));

  /// Сохраняет ник и ключ Euler Stream одним действием (перед подключением).
  Future<String?> saveTikTok({required String nickname, required String apiKey}) =>
      _save(state.copyWith(
        tiktokNickname: normalizeTiktokNickname(nickname),
        eulerApiKey: apiKey.trim(),
      ));

  /// Запоминает, включена ли связь с игрой. Возвращает текст ошибки или `null`.
  Future<String?> setMinecraftLinkEnabled(bool enabled) =>
      _save(state.copyWith(minecraftLinkEnabled: enabled));

  Future<String?> _save(AppSettings next) async {
    try {
      await ref.read(settingsRepositoryProvider).save(next);
    } catch (error) {
      final detail = error is StorageException ? error.message : '$error';
      return 'Не удалось сохранить настройки. $detail';
    }
    state = next;
    return null;
  }
}
