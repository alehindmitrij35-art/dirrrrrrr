#!/usr/bin/env node
// Dirronlive TikTok connector.
//
// Dirronlive запускает этот процесс при нажатии «Подключиться» и завершает
// при «Отключиться». Связь — строки JSON в stdout:
//   {"type":"status","status":"connecting"|"connected"|"offline"|"error"|"ended"|"disconnected", ...}
//   {"type":"gift", ...поля normalizeGift...}
// Если Dirronlive закрылся (stdin закрыт) или прислал "stop", процесс выходит.
//
// --fetch-gifts --user ник: один ответ {"type":"gifts","gifts":[{id,name,diamonds,image}]}
// (каталог подарков эфира, fetchAvailableGifts) или status error, и выход.
//
// Используется библиотека tiktok-live-connector (Node.js, AGPL-3.0):
// https://github.com/zerodytrash/TikTok-Live-Connector
import { classifyError, normalizeCatalog, normalizeGift, parseArgs, toJsonLine } from './lib.mjs';

const args = parseArgs(process.argv.slice(2));
const emit = (object) => process.stdout.write(toJsonLine(object) + '\n');

let lib;
try {
  lib = await import(process.env.DIRRONLIVE_TIKTOK_LIB || 'tiktok-live-connector');
} catch (error) {
  emit({ type: 'status', status: 'error', kind: 'service',
    message: `Не найдена библиотека tiktok-live-connector: ${error.message}` });
  process.exit(3);
}

const { TikTokLiveConnection, WebcastEvent, ControlEvent, SignConfig } = lib;

if (args.selfCheck) {
  const missing = [];
  if (typeof TikTokLiveConnection !== 'function') missing.push('TikTokLiveConnection');
  if (!WebcastEvent?.GIFT) missing.push('WebcastEvent.GIFT');
  if (!WebcastEvent?.STREAM_END) missing.push('WebcastEvent.STREAM_END');
  if (!ControlEvent?.CONNECTED) missing.push('ControlEvent.CONNECTED');
  if (!ControlEvent?.DISCONNECTED) missing.push('ControlEvent.DISCONNECTED');
  if (typeof lib.UserOfflineError !== 'function') missing.push('UserOfflineError');
  // Каталог подарков нужен только для сверки — его отсутствие не ломает эфир.
  const catalog = typeof TikTokLiveConnection?.prototype?.fetchAvailableGifts === 'function';
  emit({ type: 'selfcheck', ok: missing.length === 0, missing, catalog, version: lib.VERSION ?? null,
    node: process.version });
  process.exit(missing.length === 0 ? 0 : 4);
}

if (!args.user) {
  emit({ type: 'status', status: 'error', kind: 'service', message: 'Не указан ник TikTok.' });
  process.exit(2);
}

if (args.key && SignConfig) SignConfig.apiKey = args.key;

if (args.fetchGifts) {
  const catalogConnection = new TikTokLiveConnection(args.user, { signApiKey: args.key || undefined });
  try {
    const list = await catalogConnection.fetchAvailableGifts();
    emit({ type: 'gifts', uniqueId: args.user, gifts: normalizeCatalog(list) });
    process.exit(0);
  } catch (error) {
    emit({ type: 'status', ...classifyError(error) });
    process.exit(1);
  }
}

let finished = false;
function finish(code) {
  if (finished) return;
  finished = true;
  try { connection?.disconnect?.(); } catch { /* уже отключено */ }
  setTimeout(() => process.exit(code), 150);
}

// Dirronlive закрылся или попросил остановиться.
process.stdin.setEncoding('utf8');
process.stdin.on('data', (chunk) => { if (String(chunk).includes('stop')) finish(0); });
process.stdin.on('end', () => finish(0));
process.on('SIGTERM', () => finish(0));

emit({ type: 'status', status: 'connecting', uniqueId: args.user });

const connection = new TikTokLiveConnection(args.user, {
  signApiKey: args.key || undefined,
  // Без старых сообщений из начального пакета — иначе после переподключения
  // прошлые подарки пришли бы повторно.
  processInitialData: false,
  enableExtendedGiftInfo: false,
});

let connected = false;

connection.on(WebcastEvent.GIFT, (data) => {
  try {
    emit(normalizeGift(data));
  } catch (error) {
    emit({ type: 'log', level: 'warn', message: `Не удалось разобрать подарок: ${error.message}` });
  }
});

connection.on(WebcastEvent.STREAM_END, (event) => {
  emit({ type: 'status', status: 'ended', action: String(event?.action ?? ''),
    message: 'Эфир завершён.' });
  finish(0);
});

connection.on(ControlEvent.DISCONNECTED, (event) => {
  if (finished) return;
  emit({ type: 'status', status: 'disconnected', code: event?.code ?? null,
    message: `Соединение с эфиром прервалось${event?.reason ? `: ${event.reason}` : ''}.` });
  finish(0);
});

connection.on(ControlEvent.ERROR, (event) => {
  const error = event?.exception ?? event;
  emit({ type: 'log', level: 'error', message: String(error?.message ?? event?.info ?? error) });
});

try {
  const state = await connection.connect();
  connected = true;
  emit({ type: 'status', status: 'connected', uniqueId: args.user,
    roomId: state?.roomId ? String(state.roomId) : null });
} catch (error) {
  if (!connected) {
    const result = classifyError(error);
    emit({ type: 'status', ...result });
    finish(result.status === 'offline' ? 0 : 1);
  }
}
