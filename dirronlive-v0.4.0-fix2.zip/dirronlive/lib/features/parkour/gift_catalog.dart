import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/providers.dart';
import '../../core/storage/json_store.dart';
import '../../core/storage/storage_exception.dart';
import '../settings/settings_controller.dart';
import '../tiktok/connector_backend.dart';
import '../tiktok/gift_aggregator.dart';
import 'parkour_rules.dart';

/// Подарок из каталога эфира TikTok.
class CatalogGift {
  const CatalogGift({
    required this.id,
    required this.name,
    this.diamonds = 0,
    this.imageUrl,
  });

  final String id;

  /// Название как в TikTok («Rose»).
  final String name;
  final int diamonds;
  final String? imageUrl;

  /// Название в Dirronlive («Роза»).
  String get displayName => translateGiftName(name);

  Map<String, Object?> toJson() => {
        'id': id,
        'name': name,
        'diamonds': diamonds,
        if (imageUrl != null) 'image': imageUrl,
      };

  static CatalogGift? fromJson(Object? json) {
    if (json is! Map) return null;
    final id = json['id'];
    final name = json['name'];
    if (id == null || name is! String || name.trim().isEmpty) return null;
    final idText = '$id'.trim();
    if (idText.isEmpty || idText == '0') return null;
    final diamonds = json['diamonds'] ?? json['diamond_count'];
    final image = json['image'];
    return CatalogGift(
      id: idText,
      name: name.trim(),
      diamonds: diamonds is num ? diamonds.toInt() : 0,
      imageUrl: image is String && image.startsWith('http') ? image : null,
    );
  }

  /// Поиск по названию (английскому и русскому) или по ID.
  bool matchesQuery(String query) {
    final q = query.trim().toLowerCase();
    if (q.isEmpty) return true;
    return id.contains(q) ||
        name.toLowerCase().contains(q) ||
        displayName.toLowerCase().contains(q);
  }
}

/// Сохранённый каталог подарков эфира.
class GiftCatalog {
  const GiftCatalog({
    this.gifts = const [],
    this.fetchedAt,
    this.streamer,
  });

  final List<CatalogGift> gifts;
  final DateTime? fetchedAt;
  final String? streamer;

  bool get isEmpty => gifts.isEmpty;

  Set<String> get ids => {for (final g in gifts) g.id};

  CatalogGift? byId(String id) {
    for (final g in gifts) {
      if (g.id == id) return g;
    }
    return null;
  }

  Map<String, Object?> toJson() => {
        'version': 1,
        if (fetchedAt != null) 'fetchedAt': fetchedAt!.toUtc().toIso8601String(),
        if (streamer != null) 'streamer': streamer,
        'gifts': [for (final g in gifts) g.toJson()],
      };

  static GiftCatalog fromJson(Map<String, Object?> json) {
    final raw = json['gifts'];
    final fetched = json['fetchedAt'];
    final streamer = json['streamer'];
    return GiftCatalog(
      gifts: [
        if (raw is List)
          for (final item in raw)
            if (CatalogGift.fromJson(item) case final CatalogGift g) g,
      ],
      fetchedAt: fetched is String ? DateTime.tryParse(fetched)?.toLocal() : null,
      streamer: streamer is String && streamer.isNotEmpty ? streamer : null,
    );
  }
}

class GiftCatalogRepository {
  GiftCatalogRepository(this.store);

  static const fileName = 'gift_catalog.json';

  final JsonStore store;

  /// Читает каталог. Бросает [StorageException] / [FormatException].
  Future<GiftCatalog> read() async {
    final json = await store.read(fileName);
    return json == null ? const GiftCatalog() : GiftCatalog.fromJson(json);
  }

  Future<GiftCatalog> load() async {
    try {
      return await read();
    } catch (_) {
      return const GiftCatalog();
    }
  }

  Future<void> save(GiftCatalog catalog) => store.write(fileName, catalog.toJson());
}

/// Ошибка получения каталога: `network` — сеть, `offline` — эфир не найден,
/// `service` — TikTok или сервер подписи.
class CatalogFetchException implements Exception {
  const CatalogFetchException(this.kind, this.message);

  final String kind;
  final String message;

  @override
  String toString() => message;
}

abstract interface class GiftCatalogFetcher {
  /// Каталог подарков эфира [uniqueId]. Бросает [CatalogFetchException].
  Future<List<CatalogGift>> fetch({required String uniqueId, String? apiKey});
}

/// Запускает коннектор с `--fetch-gifts` и читает ответ.
class NodeGiftCatalogFetcher implements GiftCatalogFetcher {
  NodeGiftCatalogFetcher({this.location, this.environment, this.timeout = const Duration(seconds: 40)});

  final ConnectorLocation? location;
  final Map<String, String>? environment;
  final Duration timeout;

  @override
  Future<List<CatalogGift>> fetch({required String uniqueId, String? apiKey}) async {
    final where = location ?? ConnectorLocation.resolve();
    if (where == null) {
      throw const CatalogFetchException(
          'service', 'Коннектор TikTok не найден рядом с программой. Переустановите Dirronlive.');
    }
    final ProcessResult result;
    try {
      result = await Process.run(
        where.node,
        [
          where.script,
          '--fetch-gifts',
          '--user',
          uniqueId,
          if (apiKey != null && apiKey.isNotEmpty) ...['--key', apiKey],
        ],
        workingDirectory: where.workingDirectory,
        environment: environment,
        stdoutEncoding: utf8,
        stderrEncoding: utf8,
      ).timeout(timeout);
    } on TimeoutException {
      throw const CatalogFetchException('network', 'TikTok не ответил за 40 секунд.');
    } on ProcessException catch (e) {
      throw CatalogFetchException('service', 'Не удалось запустить коннектор: ${e.message}');
    }
    return parseFetchOutput('${result.stdout}');
  }

  /// Разбирает строки JSON коннектора (вынесено для тестов).
  static List<CatalogGift> parseFetchOutput(String stdout) {
    Map<String, Object?>? gifts;
    Map<String, Object?>? error;
    for (final line in const LineSplitter().convert(stdout)) {
      final text = line.trim();
      if (!text.startsWith('{')) continue;
      try {
        final decoded = jsonDecode(text);
        if (decoded is! Map) continue;
        final map = decoded.cast<String, Object?>();
        if (map['type'] == 'gifts') gifts = map;
        if (map['type'] == 'status' && map['status'] == 'error' ||
            map['type'] == 'status' && map['status'] == 'offline') {
          error = map;
        }
      } on FormatException {
        continue;
      }
    }
    if (gifts != null) {
      final raw = gifts['gifts'];
      return [
        if (raw is List)
          for (final item in raw)
            if (CatalogGift.fromJson(item) case final CatalogGift g) g,
      ];
    }
    if (error != null) {
      final kind = error['status'] == 'offline' ? 'offline' : '${error['kind'] ?? 'service'}';
      throw CatalogFetchException(kind, '${error['message'] ?? 'Ошибка коннектора'}');
    }
    throw const CatalogFetchException('service', 'Коннектор не вернул каталог подарков.');
  }
}

final giftCatalogFetcherProvider =
    Provider<GiftCatalogFetcher>((ref) => NodeGiftCatalogFetcher());

final initialGiftCatalogProvider = Provider<GiftCatalog>((ref) => const GiftCatalog());

/// Итог «Обновить и проверить каталог».
class CatalogReport {
  const CatalogReport({
    required this.checkedAt,
    required this.fetched,
    this.connectorCount = 0,
    this.savedCount = 0,
    this.editorCount = 0,
    this.missingInSaved = const [],
    this.missingInEditor = const [],
    this.added = const [],
    this.removed = const [],
    this.rulesWithoutGift = const [],
    this.error,
    this.errorKind,
  });

  final DateTime checkedAt;

  /// Каталог получен от коннектора в этот раз.
  final bool fetched;
  final int connectorCount;
  final int savedCount;
  final int editorCount;

  /// ID, которые прислал коннектор, но которых нет в сохранённом файле / в редакторе.
  final List<String> missingInSaved;
  final List<String> missingInEditor;

  /// Новые и пропавшие по сравнению с прошлым каталогом.
  final List<String> added;
  final List<String> removed;

  /// Правила, чьих подарков нет в каталоге этого эфира.
  final List<String> rulesWithoutGift;
  final String? error;
  final String? errorKind;

  /// Все три набора совпали — только тогда можно писать «все доступны».
  bool get allAvailable =>
      fetched && error == null && missingInSaved.isEmpty && missingInEditor.isEmpty &&
      connectorCount == savedCount && savedCount == editorCount && connectorCount > 0;
}

class GiftCatalogState {
  const GiftCatalogState({
    this.catalog = const GiftCatalog(),
    this.busy = false,
    this.report,
  });

  /// То, что видно в редакторе правил.
  final GiftCatalog catalog;
  final bool busy;
  final CatalogReport? report;
}

final giftCatalogProvider =
    NotifierProvider<GiftCatalogController, GiftCatalogState>(GiftCatalogController.new);

class GiftCatalogController extends Notifier<GiftCatalogState> {
  @override
  GiftCatalogState build() =>
      GiftCatalogState(catalog: ref.read(initialGiftCatalogProvider));

  bool knows(String giftId) => state.catalog.byId(giftId) != null;

  /// Получить каталог у коннектора, сохранить, перечитать с диска и сверить
  /// три набора ID: коннектор, файл и редактор.
  Future<CatalogReport> refreshAndCheck() async {
    if (state.busy) return state.report ?? CatalogReport(checkedAt: DateTime.now(), fetched: false);
    final clock = ref.read(clockProvider);
    final previous = state.catalog;
    final nickname = ref.read(settingsProvider).tiktokNickname.trim().replaceFirst('@', '');
    state = GiftCatalogState(catalog: previous, busy: true, report: state.report);

    CatalogReport finish(CatalogReport report) {
      state = GiftCatalogState(catalog: state.catalog, report: report);
      return report;
    }

    if (nickname.isEmpty) {
      return finish(CatalogReport(
        checkedAt: clock(),
        fetched: false,
        savedCount: previous.gifts.length,
        editorCount: previous.gifts.length,
        error: 'Укажите ник TikTok в Настройках → Подключения.',
        errorKind: 'settings',
      ));
    }

    List<CatalogGift> fetched;
    try {
      fetched = await ref.read(giftCatalogFetcherProvider).fetch(
            uniqueId: nickname,
            apiKey: ref.read(settingsProvider).eulerApiKey,
          );
    } on CatalogFetchException catch (e) {
      return finish(CatalogReport(
        checkedAt: clock(),
        fetched: false,
        savedCount: previous.gifts.length,
        editorCount: previous.gifts.length,
        error: e.message,
        errorKind: e.kind,
      ));
    }
    if (fetched.isEmpty) {
      return finish(CatalogReport(
        checkedAt: clock(),
        fetched: false,
        savedCount: previous.gifts.length,
        editorCount: previous.gifts.length,
        error: 'TikTok вернул пустой каталог подарков.',
        errorKind: 'service',
      ));
    }

    // Без повторов ID, в порядке стоимости.
    final unique = <String, CatalogGift>{for (final g in fetched) g.id: g};
    final gifts = unique.values.toList()
      ..sort((a, b) => a.diamonds != b.diamonds
          ? a.diamonds.compareTo(b.diamonds)
          : a.name.compareTo(b.name));
    final next = GiftCatalog(gifts: gifts, fetchedAt: clock(), streamer: nickname);
    final repository = GiftCatalogRepository(ref.read(jsonStoreProvider));

    GiftCatalog saved;
    String? saveError;
    try {
      await repository.save(next);
      saved = await repository.read();
    } catch (e) {
      saveError = 'Каталог получен, но не сохранён: ${e is StorageException ? e.message : e}';
      saved = const GiftCatalog();
    }

    // Редактор показывает то, что прочитано с диска (а если не записалось —
    // полученный каталог, чтобы им можно было пользоваться сейчас).
    final editor = saveError == null ? saved : next;
    state = GiftCatalogState(catalog: editor, busy: true, report: state.report);
    final editorIds = state.catalog.ids;

    final connectorIds = unique.keys.toSet();
    final savedIds = saved.ids;
    String label(String id) {
      final g = unique[id] ?? previous.byId(id);
      return g == null ? id : '${g.displayName} ($id)';
    }

    final rules = ref.read(parkourRulesProvider).rules;
    await ref.read(parkourRulesProvider.notifier).fillGiftIds({
      for (final g in gifts) g.displayName.toLowerCase(): (id: g.id, image: g.imageUrl),
      for (final g in gifts) g.name.toLowerCase(): (id: g.id, image: g.imageUrl),
    });

    return finish(CatalogReport(
      checkedAt: clock(),
      fetched: true,
      connectorCount: connectorIds.length,
      savedCount: savedIds.length,
      editorCount: editorIds.length,
      missingInSaved: [for (final id in connectorIds) if (!savedIds.contains(id)) label(id)],
      missingInEditor: [for (final id in connectorIds) if (!editorIds.contains(id)) label(id)],
      added: previous.isEmpty
          ? const []
          : [for (final id in connectorIds) if (!previous.ids.contains(id)) label(id)],
      removed: [for (final id in previous.ids) if (!connectorIds.contains(id)) label(id)],
      rulesWithoutGift: [
        for (final r in rules)
          if (r.giftId != null && !connectorIds.contains(r.giftId))
            '${r.giftName} (${r.giftId}) → ${r.actionTitle}',
      ],
      error: saveError,
      errorKind: saveError == null ? null : 'storage',
    ));
  }
}

/// Подарки, которые можно выбрать без каталога: популярные, только по названию.
const starterGiftNames = <String>[
  'Роза',
  'Сердечко',
  'Сердце',
  'Сердце руками',
  'Пончик',
  'Мороженое',
  'Духи',
  'Очки',
  'Корги',
  'Лев',
  'Ракета',
  'Галактика',
  'Вселенная',
];
