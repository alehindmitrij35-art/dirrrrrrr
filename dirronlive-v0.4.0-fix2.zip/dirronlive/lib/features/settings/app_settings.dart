/// Настройки пользователя.
class AppSettings {
  const AppSettings({
    this.tiktokNickname = '',
    this.minecraftLinkEnabled = false,
    this.eulerApiKey = '',
  });

  /// Ник TikTok без начального @. Пустая строка — ник не указан.
  final String tiktokNickname;

  /// Включена ли связь с игрой. Если да, сервер для мода поднимается
  /// сам при запуске программы.
  final bool minecraftLinkEnabled;

  /// Необязательный ключ Euler Stream (сервер подписи TikTok-Live-Connector).
  /// Без ключа работают бесплатные общие лимиты.
  final String eulerApiKey;

  AppSettings copyWith({
    String? tiktokNickname,
    bool? minecraftLinkEnabled,
    String? eulerApiKey,
  }) =>
      AppSettings(
        tiktokNickname: tiktokNickname ?? this.tiktokNickname,
        minecraftLinkEnabled: minecraftLinkEnabled ?? this.minecraftLinkEnabled,
        eulerApiKey: eulerApiKey ?? this.eulerApiKey,
      );

  Map<String, Object?> toJson() => {
        'version': 3,
        'tiktokNickname': tiktokNickname,
        'minecraftLinkEnabled': minecraftLinkEnabled,
        'eulerApiKey': eulerApiKey,
      };

  /// Понимает и файл первой версии (только ник).
  factory AppSettings.fromJson(Map<String, Object?> json) {
    final nickname = json['tiktokNickname'];
    final link = json['minecraftLinkEnabled'];
    final key = json['eulerApiKey'];
    return AppSettings(
      tiktokNickname:
          nickname is String ? normalizeTiktokNickname(nickname) : '',
      minecraftLinkEnabled: link == true,
      eulerApiKey: key is String ? key.trim() : '',
    );
  }

  @override
  bool operator ==(Object other) =>
      other is AppSettings &&
      other.tiktokNickname == tiktokNickname &&
      other.minecraftLinkEnabled == minecraftLinkEnabled &&
      other.eulerApiKey == eulerApiKey;

  @override
  int get hashCode =>
      Object.hash(tiktokNickname, minecraftLinkEnabled, eulerApiKey);
}

/// Убирает пробелы по краям и один начальный `@`.
///
/// `"  @dirron "` → `"dirron"`, `"@@dirron"` → `"@dirron"`.
String normalizeTiktokNickname(String raw) {
  var value = raw.trim();
  if (value.startsWith('@')) {
    value = value.substring(1).trimLeft();
  }
  return value;
}
