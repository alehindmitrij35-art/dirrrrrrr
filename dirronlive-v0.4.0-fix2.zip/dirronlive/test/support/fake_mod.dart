import 'dart:convert';
import 'dart:io';

import 'package:flutter_test/flutter_test.dart';

/// «Поддельный мод»: подключается к Dirronlive по WebSocket и говорит тем же
/// протоколом, что и Dirronlive Bridge в Minecraft.
class FakeMod {
  FakeMod._(this.socket) {
    socket.listen(
      (data) {
        final message = (jsonDecode(data as String) as Map).cast<String, Object?>();
        messages.add(message);
        if (message['type'] == 'action' && respondToActions) _respond(message);
      },
      onDone: () => closed = true,
    );
  }

  /// Отвечать на действия паркура, как мод 2.0 на карте.
  bool respondToActions = false;

  /// Комната игрока на «карте».
  int room = 12;

  List<Map<String, Object?>> get actions =>
      messages.where((m) => m['type'] == 'action').toList();

  List<Map<String, Object?>> get countdowns => messages
      .where((m) => m['type'] == 'countdown' || m['type'] == 'countdownCancel')
      .toList();

  void _respond(Map<String, Object?> m) {
    final params = (m['params'] as Map?)?.cast<String, Object?>() ?? const {};
    final rooms = (params['rooms'] as num?)?.toInt() ?? 1;
    final from = room;
    String result;
    switch (m['action']) {
      case 'room_back':
        room = (room - rooms).clamp(1, 100).toInt();
        result = 'Комната $from → $room';
      case 'room_forward':
        room = (room + rooms).clamp(1, 100).toInt();
        result = 'Комната $from → $room';
      case 'goto_room':
        room = ((params['room'] as num?)?.toInt() ?? room).clamp(1, 100).toInt();
        result = 'Комната $from → $room';
      case 'super_push':
        result = 'Суперсильный толчок ${params['direction'] == 'right' ? 'вправо' : 'вперёд'}';
      default:
        result = 'Выполнено: ${m['action']}';
    }
    send({'type': 'actionResult', 'id': m['id'], 'ok': true, 'result': result, 'room': room});
    parkour(room: room);
  }

  /// Мод 2.0: умеет действия, мир открыт, карта на месте.
  void helloParkour({int room = 12}) {
    this.room = room;
    send({
      'type': 'hello',
      'protocol': 2,
      'modVersion': '2.0.0',
      'minecraftVersion': '1.21.1',
      'worldReady': true,
      'parkourActions': true,
    });
    parkour(room: room);
  }

  void parkour({required int room, bool available = true}) => send({
        'type': 'parkour',
        'available': available,
        'room': room,
        'finished': false,
        'falls': 0,
        'seconds': 0,
      });

  static Future<FakeMod> connect(int port) async => FakeMod._(
      await WebSocket.connect('ws://127.0.0.1:$port/dirronlive'));

  final WebSocket socket;
  final List<Map<String, Object?>> messages = [];
  bool closed = false;

  List<Map<String, Object?>> get gifts =>
      messages.where((m) => m['type'] == 'gift').toList();

  void send(Map<String, Object?> message) => socket.add(jsonEncode(message));

  void hello({required bool worldReady}) => send({
        'type': 'hello',
        'protocol': 1,
        'modVersion': '1.0.0',
        'minecraftVersion': '1.21.1',
        'worldReady': worldReady,
      });

  void world(bool ready) => send({'type': 'world', 'worldReady': ready});

  void ack(String id) => send({'type': 'ack', 'id': id});

  Future<void> close() => socket.close();
}

/// Ждёт условия до 5 секунд.
Future<void> waitFor(bool Function() condition, {String? reason}) async {
  final stopwatch = Stopwatch()..start();
  while (!condition()) {
    if (stopwatch.elapsed > const Duration(seconds: 5)) {
      fail('Не дождались: ${reason ?? 'условие'}');
    }
    await Future<void>.delayed(const Duration(milliseconds: 10));
  }
}


